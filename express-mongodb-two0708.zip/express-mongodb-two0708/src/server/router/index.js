import express from 'express';
import hello from './hello'
import outApi from './outApi'
import inApi from './inApi'
import products from './products'
import cityName from './cityName'




export default app => {
	app.get('/api', (req, res, next) => {
		res.render('index', { title: 'Express' })
	});
	app.use('/api/hello', hello)
	app.use('/api/outApi', outApi)
	app.use('/api/testApi', inApi)
	app.use('/api/productsApi', products)
	app.use('/api/citiesApi',cityName )
    
}