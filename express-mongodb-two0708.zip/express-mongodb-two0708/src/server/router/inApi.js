import express from 'express'
import mongoose from 'mongoose'

const axios = require("axios");
const router = express.Router()
const options = {
	method: 'GET',
	url: 'https://target1.p.rapidapi.com/auto-complete',
	params: {
		q: 'macbook air'
	},
	headers: {
		'X-RapidAPI-Key': '5d7b47b586msh51f69eb62ab1ab9p195b84jsnd5958adc0540',
		'X-RapidAPI-Host': 'target1.p.rapidapi.com'
	}
};

router.get('/', function(req, res, next) {
	axios.request(options).then(function(response) {
		// console.log(response.data);
		res.json(response.data)
	}).catch(function(error) {
		// console.error(error);
		res.json(error)
	});
})
router.get('/test', function(req, res, next) {
	res.json({'name': 'targetAAA.com'})
})

export default router