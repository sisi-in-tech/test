import mongoose from 'mongoose'

const cityName = new mongoose.Schema({
	city: String,
	state: String
	 
})


const cityNameModel = mongoose.model('CityName', cityName,'cityNameStateAbbrNew');

// const userModel = mongoose.model('user', userSchema);



export default cityNameModel