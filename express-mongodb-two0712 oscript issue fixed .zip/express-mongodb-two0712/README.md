#本服务需要先下载 mongodbd数据库 或者 连接线上mongoDB  npm run dev

src\server\dist 为静态资源，由vue项目 npm run build 打包生成，部署时可用新的dist文件替换

#运行命令
npm run dev
# mongoose 必须使用版本 npm i mongoose@5.7.0 
 "mongoose": "^5.13.14",

