import express from 'express'
import mongoose from 'mongoose'

const axios = require("axios");
const router = express.Router()
const options = {
	method: 'GET',
	url: 'http://api.openweathermap.org/geo/1.0/zip?zip={zip code},{country code}&appid={API key}',
	params: {
		zip: 'macbook air90210,US',
		appid : 'eb00768af5d588e6a02de34686148288'
	},
	// headers: {
	
	// }
};

router.get('/', function(req, res, next) {
	return res.send({test: true})
})
// router.get('/test', function(req, res, next) {
// 	res.json({'name': 'targetAAA.com'})
// })

export default router
