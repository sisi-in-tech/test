import mongoose from 'mongoose'

const productSchema = new mongoose.Schema({
	name: String,
	item_number: String,
	inventory:String, 
    max_temp_celsius:Number, 
    min_temp_celsius:Number, 
    max_temp_fahrenheit:Number,
    min_temp_fahrenheit:Number,
    city:String,
    exclude_city:String,
    price:Number, 
    sort:String,
    create_time:String,
    modify_time:String,
    description:String,
    size:String,
    color:String,
    brand:String,
    image:Array,   
})


const productModel = mongoose.model('Products', productSchema,'productsAllSeasons');

// const userModel = mongoose.model('user', userSchema);



export default productModel