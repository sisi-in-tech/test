const mongoose = require('mongoose')

const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGO_URI, {
            // stop some of the warming from the console
            useNewUrlParser: true,
            // useUnifiedTopolgy: true,
            // useFindAndModify: false ,
        })

        console.log(`MongoDB Connected: ${conn.connection.host}`)
    } catch (err){
        console.error(err)
        // stop any of err , stop failure so use 1 
        process.exit(1)
    }
}


module.exports = connectDB 