/* CHALLENGE
Given a string of text, write an algorithm that returns the text received in a reversed format. 
E.g reverseString('algorithms') // should return 'smhtirogla'
*/



function reverseString(text) {
    return text.split("").reverse().join("")
}

function reverseString(text) {
    let result = ""

    for (let i = text.length -1 ; i >= 0 ; i--){
        result += text[i]
    }
    return result 
}

function reverseString(text) {
    return [...text].reverse().join("")
}


// The for...of statement in JavaScript is used to execute a certain piece of code for each distinct item(property) of an iterable object . 
function reverseString(text) {
    let result = "";

    for(let char of text){
        result = char + result 
    }
    return result ; 
}


function reverseString(text) {
    if (text === "") {
        return ""
    } else {
        // If length is 0 or negative, an empty string is returned. so substr(1)
        return reverseString(text.substr(1)) + text[0]
    }
}


// Perhaps the easiest-to-understand case for reduce() is to return the sum of all the elements in an array: reduce((previousValue, currentValue) => { /* … */ } )  '' is initialValue

function reverseString(text) {
    return text.split("").reduce((acc,char)=> char + acc, '')
}

function reverseString(text) {
    return [...text].reduce((acc,char)=> char + acc, '')
}



module.exports = reverseString